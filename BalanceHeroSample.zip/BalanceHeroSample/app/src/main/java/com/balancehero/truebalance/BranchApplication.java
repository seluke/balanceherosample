package com.balancehero.truebalance;

import android.app.Application;

import io.branch.referral.Branch;

public class BranchApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Branch.enableLogging();
        Branch.getAutoInstance(this);
    }
}
